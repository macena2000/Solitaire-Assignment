using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Solitaire : MonoBehaviour
{

    public static string[] suits = new string[] { "C", "D", "H", "S" };
    public static string[] values = new string[] { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };

    public List<string> deck;


    // Start is called before the first frame update
    void Start()
    {
        PlayCards();
    }

    // Update is called once per frame
    void Update()
    {

    }

    public static List<string> GenerateDeck()
    {
        List<string> newDeck = new List<string>();

        foreach (string s in suits)
        {
            foreach (string v in values)

            {
                newDeck.Add(s + v);
            }
        }

        return newDeck;
    }

    public void PlayCards()
    {
        deck = GenerateDeck();
        for (int i =1; i < 6; i++)
        deck = ShuffleCards(deck);

        foreach (string card in deck)
        {
            print(card);
        }

    }
    public static List<string> ShuffleCards(List<string cardDeck)
    {
        for (int card1 = 0; card1 < cardDeck.Count; card1++)
        {
            int card2 = Random.range(0, 51);
            if (card1 != card2)
            {
                string tempCard = cardDeck[card1];
                cardDeck[card1] = cardDeck[card2];
                cardDeck[card2] = tempCard;
            }
        }
        return cardDeck;
    }
}
